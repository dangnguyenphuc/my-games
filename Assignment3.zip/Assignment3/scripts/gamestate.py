class GameState:
  IS_EXIT = 0
  IS_START = 1
  OPEN_OPTS = 2
  IS_PLAY = 3
  IS_PAUSE = 4
  IS_WEAPON = 5
  IS_WEAPON_S = 6
  IS_WEAPON_G = 7
