#ifndef CONFIG_HPP
#define CONFIG_HPP

#pragma once
#include <vector>

#define SCREEN_WIDTH 1120
#define SCREEN_HEIGHT 800

#define SCREEN_CENTER_WIDTH SCREEN_WIDTH/2
#define SCREEN_CENTER_HEIGHT SCREEN_HEIGHT/2

#define FPS 60
#define FRAME_DELAY 1000/FPS
#define SPEED 100

#define MAX_NUM_OF_PLAYERS 3

#define GROUP_MAP 0
#define GROUP_LINE 1
#define GROUP_PLAYER1 2
#define GROUP_PLAYER2 3
#define GROUP_BALL 4
#define GROUP_MUD 5

#define TIME_TO_PLAY 60 // sec

#define JETBRAINSMONO_FONT_FILE_PATH "../assets/font/JetBrainsMonoNerdFontMono-Regular.ttf"
#define TIMER_BORDER_TEXTURE_FILE_PATH "../assets/image/Free_Assets/Counter/Border.png"
#define SCORE_BORDER_TEXTURE_FILE_PATH "../assets/image/Free_Assets/Counter/ScoreBorder.png"

// start menu
#define START_MENU_P1_BUTTON "../assets/image/Menu/pwp_btn.png"
#define START_MENU_P2_BUTTON "../assets/image/Menu/pwc_btn.png"
#define START_MENU_BACKGROUND "../assets/image/Menu/start_bg.png"

// end menu
#define END_MENU_BACKGROUND "../assets/image/Menu/end_bg.png"
#define END_MENU_REPLAY_BUTTON "../assets/image/Menu/replay_btn.png"
#define END_MENU_RETURN_BUTTON "../assets/image/Menu/return_btn.png"

// ball
#define BALL_TEXTURE_FILE_PATH "../assets/image/ball.png"

// Map
#define MAP_WIDTH 18  //  1120/32
#define MAP_HEIGHT 38 //  800/32

#define ZONE_HEIGHT 533
#define ZONE_WIDTH  560

// Grass Tile
#define GRASS_TILE_FILE_PATH "../assets/image/Tiles/grass.png"
#define MUD_TILE_FILE_PATH "../assets/image/Tiles/Mud.png"
#define GRASS_TILE_WIDTH_HEIGHT 32
#define GRASS_TILE_WIDTH_HEIGHT_2_DRAW 64

// Line
#define LINE_TEXTURE_FILE_PATH "../assets/image/Tiles/line.png"
#define LINE_H_TEXTURE_FILE_PATH "../assets/image/Tiles/line-horizontal.png"
#define LINE1_TEXTURE_FILE_PATH "../assets/image/Tiles/line1.png"
#define LINE2_TEXTURE_FILE_PATH "../assets/image/Tiles/line2.png"

// ARGENTINA
#define ARGENTINA_WALK "../assets/image/Free_Assets/Footballers/Argentina/walk.png"
#define ARGENTINA_IDLE "../assets/image/Free_Assets/Footballers/Argentina/idle.png"
#define ARGENTINA_FRONT "../assets/image/Free_Assets/Footballers/Argentina/front.png"
#define ARGENTINA_BACK "../assets/image/Free_Assets/Footballers/Argentina/back.png"

// BOCAJUNIORS
#define BOCAJUNIORS_WALK "../assets/image/Free_Assets/Footballers/BocaJuniors/walk.png"
#define BOCAJUNIORS_IDLE "../assets/image/Free_Assets/Footballers/BocaJuniors/idle.png"
#define BOCAJUNIORS_FRONT "../assets/image/Free_Assets/Footballers/BocaJuniors/front.png"
#define BOCAJUNIORS_BACK "../assets/image/Free_Assets/Footballers/BocaJuniors/back.png"

// INDEPENDIENTE
#define INDEPENDIENTE_WALK "../assets/image/Free_Assets/Footballers/Independiente/walk.png"
#define INDEPENDIENTE_IDLE "../assets/image/Free_Assets/Footballers/Independiente/idle.png"
#define INDEPENDIENTE_FRONT "../assets/image/Free_Assets/Footballers/Independiente/front.png"
#define INDEPENDIENTE_BACK "../assets/image/Free_Assets/Footballers/Independiente/back.png"

// RIVERPLATE
#define RIVERPLATE_WALK "../assets/image/Free_Assets/Footballers/RiverPlate/walk.png"
#define RIVERPLATE_IDLE "../assets/image/Free_Assets/Footballers/RiverPlate/idle.png"
#define RIVERPLATE_FRONT "../assets/image/Free_Assets/Footballers/RiverPlate/front.png"
#define RIVERPLATE_BACK "../assets/image/Free_Assets/Footballers/RiverPlate/back.png"


// SANLORENZO
#define SANLORENZO_WALK "../assets/image/Free_Assets/Footballers/SanLorenzo/walk.png"
#define SANLORENZO_IDLE "../assets/image/Free_Assets/Footballers/SanLorenzo/idle.png"
#define SANLORENZO_FRONT "../assets/image/Free_Assets/Footballers/SanLorenzo/front.png"
#define SANLORENZO_BACK "../assets/image/Free_Assets/Footballers/SanLorenzo/back.png"

// FOOTBALLER STATES
#define IDLE 0
#define WALK_RIGHT 1
#define WALK_FRONT 2
#define WALK_BACK 3

// footballers sprite sheet
extern std::vector<std::tuple<const char*, int, int, int>> ArgentinaFootballerSprite;
extern std::vector<std::tuple<const char*, int, int, int>> BocaFootballerSprite;
extern std::vector<std::tuple<const char*, int, int, int>> IndependienteFootballerSprite;
extern std::vector<std::tuple<const char*, int, int, int>> RiverPlateFootballerSprite;
extern std::vector<std::tuple<const char*, int, int, int>> SanLorenzoFootballerSprite;

// map
extern int defaultMap[MAP_HEIGHT][MAP_WIDTH];

// star for current choosing footballer
#define PLAYER1_STAR "../assets/image/Free_Assets/Star/Active.png"
#define PLAYER2_STAR "../assets/image/Free_Assets/Obstacles/SnowFlake.png"

#endif