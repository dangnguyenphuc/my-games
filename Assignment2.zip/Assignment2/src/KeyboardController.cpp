#include "../include/ECS/KeyboardController.hpp"

int FootballKeyboardController::currentId = 0;